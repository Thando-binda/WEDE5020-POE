
document.addEventListener("DOMContentLoaded", function() {

    // ENQUIRY FORM VALIDATION & AJAX
    
    const enquiryForm = document.getElementById('enquiryForm');
    
    if (enquiryForm) { // Only runs if we are on Enquiry.html
        enquiryForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Stops page reload
            
            let name = document.getElementById('name').value.trim();
            let email = document.getElementById('email').value.trim();
            let phone = document.getElementById('number').value.trim();
            let enquiryType = document.getElementById('enquiryType').value;
            let message = document.getElementById('message').value.trim();
            let errorDiv = document.getElementById('formError');
            let submitBtn = document.getElementById('submitBtn');
            
            errorDiv.style.display = "none";
            
            // Validation Checks
            if(name.length < 3) {
                errorDiv.innerText = "Please enter a valid full name (at least 3 characters).";
                errorDiv.style.display = "block";
                return;
            }
            if(!email.includes('@') || !email.includes('.')) {
                errorDiv.innerText = "Please enter a valid email address.";
                errorDiv.style.display = "block";
                return;
            }
            if(!/^\d{10}$/.test(phone)) {
                errorDiv.innerText = "Please enter a valid 10-digit phone number.";
                errorDiv.style.display = "block";
                return;
            }
            if(enquiryType === "") {
                errorDiv.innerText = "Please select a type of enquiry.";
                errorDiv.style.display = "block";
                return;
            }
            if(message.length < 10) {
                errorDiv.innerText = "Please provide more details (at least 10 characters).";
                errorDiv.style.display = "block";
                return;
            }
            
            // Simulate AJAX Submissiom
            submitBtn.value = "Sending...";
            submitBtn.disabled = true;
            
            setTimeout(function() {
                alert("Success! Your enquiry has been sent.");
                enquiryForm.reset();
                submitBtn.value = "Send Enquiry";
                submitBtn.disabled = false;
            }, 1500);
        });
    }


    // CONTACT FORM VALIDATION & AJAX

    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            let name = document.getElementById('cName').value.trim();
            let email = document.getElementById('cEmail').value.trim();
            let msgType = document.getElementById('cMessageType').value;
            let message = document.getElementById('cMessage').value.trim();
            let errorDiv = document.getElementById('contactError');
            let submitBtn = document.getElementById('contactSubmitBtn');
            
            errorDiv.style.display = "none";
            
            if(name === "") {
                errorDiv.innerText = "Please enter your name.";
                errorDiv.style.display = "block";
                return;
            }
            if(!email.includes('@')) {
                errorDiv.innerText = "Please enter a valid email address.";
                errorDiv.style.display = "block";
                return;
            }
            if(msgType === "") {
                errorDiv.innerText = "Please select a message type.";
                errorDiv.style.display = "block";
                return;
            }
            if(message.length < 5) {
                errorDiv.innerText = "Please type a message.";
                errorDiv.style.display = "block";
                return;
            }
            
            submitBtn.value = "Sending...";
            submitBtn.disabled = true;
            
            setTimeout(function() {
                alert("Thank you! Your message has been sent.");
                contactForm.reset();
                submitBtn.value = "Send Message";
                submitBtn.disabled = false;
            }, 1500);
        });
    }

    
    // LIGHTBOX GALLERY

    const lightbox = document.getElementById('lightbox');
    
    if (lightbox) {
        const triggers = document.querySelectorAll('.lightbox-trigger');
        const lightboxImg = document.getElementById('lightbox-img');
        const closeBtn = document.getElementById('close-lightbox');

        triggers.forEach(trigger => {
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                lightboxImg.src = this.href;
                lightbox.classList.remove('hidden');
            });
        });
        
        closeBtn.addEventListener('click', () => lightbox.classList.add('hidden'));
        
        // Close lightbox if user clicks outside the image
        lightbox.addEventListener('click', function(e) {
            if(e.target === lightbox) {
                lightbox.classList.add('hidden');
            }
        });
    }


    // PRODUCT SEARCH FILTER
    const searchBar = document.getElementById('searchBar');
    
    if (searchBar) {
        searchBar.addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let products = document.querySelectorAll('.product-item');
            
            products.forEach(product => {
                let text = product.innerText.toLowerCase();
                if(text.includes(filter)) {
                    product.style.display = 'block';
                } else {
                    product.style.display = 'none';
                }
            });
        });
    }
    const accordions = document.getElementsByClassName("accordion");
    
    if (accordions.length > 0) {
        for (let i = 0; i < accordions.length; i++) {
            accordions[i].addEventListener("click", function() {
                this.classList.toggle("active");
                let panel = this.nextElementSibling;
                if (panel.style.display === "block") {
                    panel.style.display = "none";
                } else {
                    panel.style.display = "block";
                }
            });
        }
    }
});