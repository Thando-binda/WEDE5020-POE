document.addEventListener("DOMContentLoaded", function() {
    

    const modalHTML = `
        <div id="imageModal" class="image-modal hidden">
            <span id="closeModal" class="close-modal">&times;</span>
            <img id="modalImage" class="modal-content" src="" alt="Zoomed Image">
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    const closeBtn = document.getElementById('closeModal');
    const galleryImages = document.querySelectorAll('.gallery-img');

    if (galleryImages.length > 0) {
        
        galleryImages.forEach(img => {
            img.style.cursor = 'pointer';
            
            img.addEventListener('click', function() {
                modal.classList.remove('hidden');
                modalImg.src = this.src;
                modalImg.classList.remove('zoomed');
            });
        });

        modalImg.addEventListener('click', function(e) {
            e.stopPropagation(); 
            this.classList.toggle('zoomed');
        });

        closeBtn.addEventListener('click', function() {
            modal.classList.add('hidden');
            modalImg.classList.remove('zoomed');
        });

        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.add('hidden');
                modalImg.classList.remove('zoomed');
            }
        });
    }
});